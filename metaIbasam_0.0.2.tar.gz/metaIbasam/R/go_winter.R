go_winter <-
function () 
{
    .C("go_winter", PACKAGE = "metaIbasam")
    invisible(NULL)
}
