autumn <-
function () 
{
    .C("autumn", PACKAGE = "metaIbasam")
    invisible(NULL)
}
