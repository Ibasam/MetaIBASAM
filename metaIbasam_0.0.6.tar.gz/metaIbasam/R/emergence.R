emergence <-
function () 
{
    .C("emergence", PACKAGE = "metaIbasam")
    invisible(NULL)
}
