spring <-
function () 
{
    .C("spring", PACKAGE = "metaIbasam")
    invisible(NULL)
}
