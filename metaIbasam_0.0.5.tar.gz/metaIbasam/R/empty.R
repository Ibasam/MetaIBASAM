empty <-
function () 
{
    .C("empty", PACKAGE = "metaIbasam")
    invisible(NULL)
}
