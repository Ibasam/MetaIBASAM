reproduce <-
function () 
{
    .C("reproduce", PACKAGE = "Ibasam")
    invisible(NULL)
}
