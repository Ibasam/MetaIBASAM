spring <-
function () 
{
    .C("spring", PACKAGE = "Ibasam")
    invisible(NULL)
}
