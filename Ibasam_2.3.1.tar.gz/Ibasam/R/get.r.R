get.r <-
function (i, nr) 
{
    i%%nr + 1
}
