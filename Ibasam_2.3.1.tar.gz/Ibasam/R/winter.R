winter <-
function () 
{
    .C("winter", PACKAGE = "Ibasam")
    invisible(NULL)
}
