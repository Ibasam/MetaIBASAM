reproduce <-
function () 
{
    .C("reproduce", PACKAGE = "metaIbasam")
    invisible(NULL)
}
