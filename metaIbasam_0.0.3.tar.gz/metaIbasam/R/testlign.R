testlign <-
function (linet, test) 
{
    return(all(linet == test))
}
