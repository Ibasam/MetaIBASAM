go_summer <-
function () 
{
    .C("go_summer", PACKAGE = "metaIbasam")
    invisible(NULL)
}
